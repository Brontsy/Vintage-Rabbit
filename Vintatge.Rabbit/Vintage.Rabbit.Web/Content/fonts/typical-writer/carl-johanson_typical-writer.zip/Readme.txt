Typical Writer is a totally free font!

Copyright Carl Johanson 1998.

This font may not be sold or/and altered without my written permission.
This font may be redistributed freely as long as this file is included.